# Parâmetros unitários de linhas de transmissão aéreas

Frontend em Python (Streamlit) para o cálculo das matrizes de impedância (**Z**)
e admitância (**Y**) por unidade de comprimento de linhas aéreas, a partir da
tabela de condutores CAA (ACSR). Desenvolvido para a disciplina
**EEE 457 — Transmissão de Energia Elétrica** (Escola Politécnica / COPPE — UFRJ).

A metodologia de cálculo reproduz a do notebook
`eee457-06_calculo_param_unitarios.ipynb` — rotina `czyl_overhead_bundled`.

## Arquivos

| Arquivo | Função |
|---|---|
| `app.py` | Interface Streamlit (frontend) |
| `lt_core.py` | Núcleo de cálculo: catenária, leitura da tabela, geometria, Z/Y |
| `line_cable_param.py` | Rotinas eletromagnéticas (módulo original, sem alterações) |
| `condutores-caa.csv` | Tabela de 66 condutores CAA |
| `requirements.txt` | Dependências |

Os quatro primeiros arquivos devem permanecer na **mesma pasta**.

## Execução

Com `uv`:

```bash
uv run --with-requirements requirements.txt streamlit run app.py
```

Ou em um ambiente já preparado:

```bash
pip install -r requirements.txt
streamlit run app.py
```

O navegador abre em `http://localhost:8501`.

## O que o aplicativo faz

1. **Lê a tabela de condutores** (CSV) e extrai, do condutor escolhido, as
   grandezas necessárias: diâmetro externo (raio `r_f`), diâmetro da alma de
   aço (raio interno `r_int`), resistência CC e massa.
2. **Calcula a flecha pela catenária**: `f = a·(cosh(L/2a) − 1)`, com
   `a = H/w`. O peso linear `w` vem da tabela; a tração horizontal `H` é dada
   como percentual da carga de ruptura (RTS). Há também a opção de informar a
   flecha diretamente.
3. **Para-raios**: considerados 3/8" EHS. A flecha é obtida da catenária
   ajustada ao valor típico de **15,24 m para um vão de 457,2 m**, reescalonada
   para o vão informado.
4. **Monta as coordenadas** de todos os subcondutores. A altura média de cada
   condutor é `y = y_fixação − (2/3)·flecha`.
5. **Calcula Z e Y** com `czyl_overhead_bundled` (impedância externa de Carson,
   impedância interna de condutor tubular, redução de Kron dos para-raios e
   redução de feixe).
6. **Apresenta** as matrizes em Ω/km e μS/km, as componentes de sequência, a
   impedância característica `Z₀ = √(z₁/y₁)` e a potência natural
   `Pₙ = Vₙ²/Re(Z₀)`, além dos gráficos da estrutura e do perfil de catenária.

## Reproduzindo o notebook

Para recuperar a primeira configuração do notebook (circuito 345 kV, dois
condutores Tern), use: condutor **TERN**, `nb = 2`, espaçamento `0,4572 m`,
geometria das fases já preenchida por padrão, **flecha de fase direta = 19,1 m**
e **flecha dos para-raios direta = 15,24 m**.
